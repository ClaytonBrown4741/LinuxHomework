/*
* wyls.c
* Author: Clayton Brown
* Date: Feb 18, 2023
*
* COSC 3750, Homework 5
*
* This is an altered version of the ls utility. It
* will take a number of arguments (along with some
* options that the user can toggle on and off) and
* display files along with their information
*
*/



// Include necessary packages
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<dirent.h>
#include<errno.h>
#include <pwd.h>
#include <grp.h>
#include<time.h>
#include <stdbool.h>

// Define the method that's used to print out the final string
void infoLister(char fileName[], bool nOption, bool hOption, char shortenedFileName[]);

// Begin the main class
int main(int argc, char **argv, char **envp)
{
  // Define/initialize my variables
  char currDir[256];
  char bufferDir[256];
  DIR* directory;
  struct dirent* entry;
  bool nOption=false;
  bool hOption=false;
  bool readingOptions=true;
  int statErrorChecker=0;
  struct stat sbuff;
  int argCounter=1;
  getcwd(currDir, 256);
  
  // This loop goes through the arguments given to the program and
  // sees if any options were utilized. If they were, mark them as
  // such and then keep track of how many options were used
  for (int i=1; i<argc; i++){
    if (readingOptions == true && strcmp(argv[i], "-n") == 0)
    {
      nOption=true;
      argCounter++;
    }
    else if (readingOptions == true && strcmp(argv[i], "-h") == 0)
    {
      hOption=true;
      argCounter++;
    }
    else if (readingOptions == true && strcmp(argv[i], "-nh") == 0){
      hOption=true;
      nOption=true;
      argCounter++;
    }
    else if (readingOptions == true && strcmp(argv[i], "-hn") == 0){
      hOption=true;
      nOption=true;
      argCounter++;
    }
    else
      readingOptions=false;
  }


  // If no specific file names were given, list off files in the
  // current directory
  if(readingOptions==true){
    directory=opendir(currDir);
    if(directory==NULL) {
      perror(currDir);
      return 0;
    }
    entry=readdir(directory);
    while(entry != NULL) {
      infoLister(entry->d_name, nOption, hOption, entry->d_name);
      entry=readdir(directory);
      }
    closedir(directory);
    printf("\n");
  }

  // If specific file names were given, go through all of then
  // and list out any attributes that they have
  else{
    for (int i=argCounter; i<argc; i++)
    {
      statErrorChecker=lstat(argv[i], &sbuff);
      // If the file doesn't exist, say so and then exit the loop
      if (statErrorChecker==-1){
        fprintf(stderr,"\nwyls: cannot access '%s': No such file or directory\n",
                        argv[i]);
        continue;
      }
      // If the file was a directory, open it and read in the different
      // entries within it
      if (S_ISDIR(sbuff.st_mode) != 0){
        printf("\n%s:", argv[i]);
        directory=opendir(argv[i]);
	// If there's an error opening the directory, say so and continue
        if(directory==NULL) {
          perror(argv[i]);
          continue;
        }
        entry=readdir(directory);
        while(entry != NULL) {
          if(strcmp(entry->d_name, ".")!=0 && strcmp(entry->d_name, "..")!=0){
            sprintf(bufferDir, "%s%s", argv[i], entry->d_name);
            infoLister(bufferDir, nOption, hOption, entry->d_name);
          }
          entry=readdir(directory);
        }
      closedir(directory);
      printf("\n");
      }
      // If the argument is just a regular file, list out the info from it
      else{
        infoLister(argv[i], nOption, hOption, argv[i]);
        printf("\n");
      }
    }    
  }
}


// void infoLister(char fileName[], bool nOption, bool hOption, char 
// shortenedFileName[]) 
// Parameters: Full pathname of the file, whether the n option is 
//   toggled, whether the h option is toggled, shortened file name 
//   without the full path (for displaying purposes)
// Return Value: Returns nothing, but prints out a lot of info
// Purpose: This function is responsible for properly formatting the
//   information about any given file. This includes file type,
//   name, permissions, etc.
void infoLister(char fileName[], bool nOption, bool hOption, char shortenedFileName[]){
    // If the file is . or .. then simply return.
    if(strcmp(fileName, ".")==0 || strcmp(fileName, "..")==0)
      return;

    // Define and initialize the varaibles
    time_t seconds = time(NULL);
    char fileType='-';
    struct passwd* pws;
    struct group* g;
    size_t rtn;
    struct tm *tptr;
    char tmpbuf[512];
    char time_string[512];
    struct stat sbuff;
    double sizeTotal=0.0;
    char formattedSize[30];
    char linkName[256];
    int errorChecker=0;
    lstat(fileName, &sbuff);

    // The defines the type of the file
    fileType='-';
    if (S_ISDIR(sbuff.st_mode)!=0)
      fileType='d';
    else if(S_ISLNK(sbuff.st_mode)!=0){
      fileType='l';
    }
       
    // This defines the permissions of the file
    printf("\n%c", fileType);
    printf( (sbuff.st_mode & S_IRUSR) ? "r" : "-");
    printf( (sbuff.st_mode & S_IWUSR) ? "w" : "-");
    printf( (sbuff.st_mode & S_IXUSR) ? "x" : "-");
    printf( (sbuff.st_mode & S_IRGRP) ? "r" : "-");
    printf( (sbuff.st_mode & S_IWGRP) ? "w" : "-");
    printf( (sbuff.st_mode & S_IXGRP) ? "x" : "-");
    printf( (sbuff.st_mode & S_IROTH) ? "r" : "-");
    printf( (sbuff.st_mode & S_IWOTH) ? "w" : "-");
    printf( (sbuff.st_mode & S_IXOTH) ? "x" : "-");
    
    // This gets the group and user id of the file
    pws = getpwuid(sbuff.st_uid);
    g = getgrgid(sbuff.st_gid);

    // Make sure that the names were successfully retrieved
    // If they were, then print out the id's or names
    // If the n option is enabled, print out the raw id's
    // Otherwise, print out the names the id's belong to
    if (pws==NULL || g==NULL){
      perror("invalid id's");
      return;
    }
    else{
      if (nOption==true)
        printf(" %9d %9d", sbuff.st_uid, sbuff.st_gid);
      else
        printf(" %9s %9s", pws->pw_name, g->gr_name);
    }

    // These if statements decide how to properly format the
    // file size output.
    if(hOption){
      if (sbuff.st_size<1024){
        printf(" %7ld  ", sbuff.st_size);
      }
      else if(sbuff.st_size<1048576){
        if ((sbuff.st_size%1024)<=52){
          printf("%7ldK  ", sbuff.st_size/1024);
        }
        else{
          sizeTotal=sbuff.st_size/1024.0;
          sizeTotal=sizeTotal*1;
          sprintf(formattedSize, "%.1fK", sizeTotal);
          printf(" %7s  ", formattedSize);
        }
      }
      else if(sbuff.st_size<1073741824){
        if ((sbuff.st_size%1048576)<=52428){
          printf("%7ldM  ", sbuff.st_size/1048576);
        }
        else{
          sizeTotal=sbuff.st_size/1048576.0;
          sprintf(formattedSize, "%.1fM", sizeTotal);
          printf(" %7s  ", formattedSize);
        }
      }
      else{
        if ((sbuff.st_size%1073741824)<=53687091){
          printf("%7ldG  ", sbuff.st_size/1073741824);
        }
        else{
          sizeTotal=sbuff.st_size/1073741824.0;
          sprintf(formattedSize, "%.1fG", sizeTotal);
          printf(" %7s  ", formattedSize);
        }
      }
    }
    else
      printf(" %7ld  ", sbuff.st_size);


    // This finds the time the file was last modified and
    // formats it in a readable way
    time_t current = sbuff.st_mtime;
    tptr=localtime(&current);
    // If an error was encountered when getting time, say so and continue
    if(tptr ==NULL) {
      sprintf(tmpbuf,"invalid time: %ld",current);
      perror(tmpbuf);
    }

    // Change the display of last modification time
    // depending on whether it was touched in the last
    // half year.
    if ((seconds-(sbuff.st_mtime)) > (15552000))
      rtn=strftime(time_string,512,"%b %d  %Y", tptr);
    else
      rtn=strftime(time_string,512,"%b %d %H:%M",tptr);

    //If there was an error, let the user know
    if(rtn < 0 ) {
      perror("formatting time");
    }
    else{
      printf("%s  ", time_string);
    }

    // Print out the last string modification
    // then the filename then return
    printf("%s",shortenedFileName);


    // If the file is a link (and there are no errors seeing where
    // the link goes) print out the special link format
    if(S_ISLNK(sbuff.st_mode)!=0){
      errorChecker=readlink(fileName, linkName, sizeof(linkName)-1);
      if (errorChecker==-1){
        perror(shortenedFileName);
        return;
      }
      printf(" -> %s", linkName);
    }

    return;
}
